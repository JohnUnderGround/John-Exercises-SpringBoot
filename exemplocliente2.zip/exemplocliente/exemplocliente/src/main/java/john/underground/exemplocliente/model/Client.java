package john.underground.exemplocliente.model john.underground.exemplocliente;

public class Client {
}
