package john.underground.exemploconstructpredestroy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExemploconstructpredestroyApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExemploconstructpredestroyApplication.class, args);
	}

}
