package john.underground.exemplolombox;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExemplolomboxApplicationTests {

	@Test
	void contextLoads() {
	}

}
