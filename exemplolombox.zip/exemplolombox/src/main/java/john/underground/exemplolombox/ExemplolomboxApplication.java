package john.underground.exemplolombox;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExemplolomboxApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExemplolomboxApplication.class, args);
	}

}
