package john.underground.exemploinjecaodedependencia.interfaces;

/**
 * @author John
 */
public interface AnimalInterface {

    public void comunicar();

}
