package john.underground.exemplohelloworld;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExemplohelloworldApplicationTests {

	@Test
	void contextLoads() {
	}

}
